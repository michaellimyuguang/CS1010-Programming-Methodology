// Unit16_String_vs_Pointer.c 
#include <stdio.h>

int main(void) {
	char str[] = "apple";

	printf("1st character: %c\n", str[0]);
	printf("1st character: %c\n", *str);

	printf("5th character: %c\n", str[4]);
	printf("5th character: %c\n", *(str+4));

	return 0;
}

