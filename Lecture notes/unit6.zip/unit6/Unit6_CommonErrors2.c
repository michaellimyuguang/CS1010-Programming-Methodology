// Unit6_CommonErrors2.c
#include <stdio.h>

int main(void) {    
	int a = 3;

	if (a > 10);
		printf("a is larger than 10\n");
	else
		printf("a is not larger than 10\n");

	printf("Next line.\n"); 

	return 0;
}

