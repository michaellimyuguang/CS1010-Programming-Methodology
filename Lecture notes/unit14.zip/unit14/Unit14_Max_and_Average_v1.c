// Unit14_Max_and_Average_v1.c 
#include <stdio.h>

int findMaximum(int [], int);
double findAverage(int [], int);

int main(void) {
	int numbers[10] = { 1, 5, 3, 6, 3, 2, 1, 9, 8, 3 };

	int max = findMaximum(numbers, 10);
	double ave = findAverage(numbers, 10);

	printf("max = %d, average = %.2f\n", max, ave);
	return 0;
}

// Compute maximum value in arr
// Precond: size > 0
int findMaximum(int arr[], int size) {
	int i, max;

	max = arr[0];
	for (i=1; i<size; i++) {
		if (arr[i] > max)
			max = arr[i];
	}
	return max;
}

// Compute average value in arr
// Precond: size > 0
double findAverage(int arr[], int size) {
	int i;
	double sum = 0.0;

	for (i=0; i<size; i++) {
		sum += arr[i];
	}
	return sum/size;
}

