// Unit14_Swap_v3.c 
// Corrected modularised version of Unit14_Swap.c
#include <stdio.h>

void swap(int *, int *);

int main(void) {
	int var1, var2;

	printf("Enter two integers: ");
	scanf("%d %d", &var1, &var2);

	swap(&var1, &var2); 

	printf("var = %d; var2 = %d\n", var1, var2);
	return 0;
}

void swap(int *ptr1, int *ptr2) {
	int temp;

	temp = *ptr1;
	*ptr1 = *ptr2;
	*ptr2 = temp;
}

