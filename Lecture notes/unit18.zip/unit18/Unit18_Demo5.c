// Unit18_Demo5.c 
#include <stdio.h>
#include <string.h>

typedef struct {
	char name[12];
	int  age;
	char gender;
} player_t;

player_t scan_player();
void print_player(char *, player_t);

int main(void) {
	player_t player1, player2;

	printf("Enter player 1's particulars:\n");
	player1 = scan_player();
	printf("Enter player 2's particulars:\n");
	player2 = scan_player();

	print_player("player1", player1);
	print_player("player2", player2);

	return 0;
}

// To read in particulars of a player and return
// the structure to the caller
player_t scan_player() {
	player_t player;

	printf("Enter name, age and gender: ");
	scanf("%s %d %c", player.name, &player.age, &player.gender);

	return player;
}

void print_player(char *header, player_t player) {
	printf("%s: name = %s; age = %d; gender = %c\n", header,
			player.name, player.age, player.gender);
}

