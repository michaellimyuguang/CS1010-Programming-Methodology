/*
 *  Unit13_FreezerMain.c
 *  From Unit 4 Exercise 6: Estimate temperature in a freezer
 *  given the elapsed time since power failure.
 *  Formula: T = (4*t^10 / (t^9+2)) - 20
 */
#include <stdio.h>
#include "Unit13_FreezerTemp.h"

int main(void) {
	int hours, minutes;
	float hours_float;  // Convert hours and minutes into hours_float
	float temperature;  // Temperature in freezer

	// Get the hours and minutes
	printf("Enter hours and minutes since power failure: ");
	scanf("%d %d", &hours, &minutes);

	// Convert hours and minutes into hours_float
	hours_float = hours + minutes/60.0;

	// For checking only
	// printf("hours_float = %f\n", hours_float);

	// Compute new temperature in freezer
	temperature = calc_temperature(hours_float);

	// Print new temperature
	printf("Temperature in freezer = %.2f\n", temperature);

	return 0;
}

