// Unit19_Formatted_IO_v2.c 
#include <stdio.h>
#include <stdlib.h>

int main(void) {
	FILE *infile, *outfile;
	char x;
	int y;
	float z;

	if ((infile = fopen("formatted.in", "r")) == NULL) {
		printf("Cannot open file \"formatted.in\"\n");
		exit(1);
	}

	if ((outfile = fopen("formatted.out", "w")) == NULL) {
		printf("Cannot open file \"formatted.out\"\n");
		exit(2);
	}

	fscanf(infile, "%c %d %f", &x, &y, &z);
	fprintf(outfile, "Data read: %c %d %.2f\n", x, y, z);

	fclose(infile);
	fclose(outfile);
	return 0;
}

