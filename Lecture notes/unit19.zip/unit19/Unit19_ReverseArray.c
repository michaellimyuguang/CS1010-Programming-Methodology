// Unit19_ReverseArray.c
// Reverse the elements in an array.
#include <stdio.h>
#define MAX_SIZE 10

int scanArray(int []);
void printArray(int [], int);
void reverseArray(int [], int);

int main(void) {
	int array[MAX_SIZE], size;

	size = scanArray(array);

	reverseArray(array, size);

	printf("After reversing: ");
	printArray(array, size);

	return 0;
}

// Read elements into array and return number of elements read.
int scanArray(int arr[]) {
	int size, i;

	printf("Enter size of array (<=%d): ", MAX_SIZE);
	scanf("%d", &size);

	for (i=0; i<size; i++) {
		scanf("%d", &arr[i]);
	}

	return size;
}

// Print array
void printArray(int arr[], int size) {
	int i;

	for (i=0; i<size; i++) {
		printf("%d ", arr[i]);
	}
	printf("\n");
}

// Reverse the array
void reverseArray(int arr[], int size) {
	int i, temp;

	for (i=0; i<size/2; i++) {
		temp = arr[i];
		arr[i] = arr[size-i-1];
		arr[size-i-1] = temp;
	}
}

