// Unit19_SumArray.c 
#include <stdio.h>
#define MAX 10   // maximum number of elements

int scanPrices(float []);
float sumPrices(float [], int);
void printResult(float);

int main(void) {
	float prices[MAX]; 
	int size = scanPrices(prices);
	printResult(sumPrices(prices, size));

	return 0;
}

// Compute sum of elements in arr
float sumPrices(float arr[], int size) {
	float sum = 0.0;
	int i;

	for (i=0; i<size; i++)
		sum += arr[i];

	return sum;
}

// Read number of prices and prices into array arr.
// Return number of prices read.
int scanPrices(float arr[]) {
	int size, i;

	printf("Enter number of prices: ");
	scanf("%d", &size);

	printf("Enter prices:\n");
	for (i=0; i<size; i++) 
		scanf("%f", &arr[i]);

	return size;
}

// Print the total price
void printResult(float total_price) {
	printf("Total price = $%.2f\n", total_price);
}

