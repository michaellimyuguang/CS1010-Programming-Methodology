// Unit19_CopyFile.c 
#include <stdio.h>
#include <stdlib.h>
#define FILENAME_LENGTH 30

int copyFile(char [], char []);

int main(void) {
	char input_filename[FILENAME_LENGTH+1], 
	     output_filename[FILENAME_LENGTH+1];

	printf("What is the input filename? ");
	scanf("%s", input_filename);
	printf("What is the output filename? ");
	scanf("%s", output_filename);

	// copy input file to output file
	copyFile(input_filename, output_filename);

	return 0;
}

// Copy text from sourcefile to destfile
int copyFile(char sourcefile[], char destfile[]) {
	FILE *sfp, *dfp;
	int ch;

	if ((sfp = fopen(sourcefile, "r")) == NULL) {
		exit(1);  // error - can't open source file
	}

	if ((dfp = fopen(destfile, "w")) == NULL) {
		fclose(sfp); // close source file
		exit(2);  // error - can't open destination file
	}

	while ((ch = fgetc(sfp)) != EOF) {
		if (fputc(ch, dfp) == EOF) {
			fclose(sfp); 
			fclose(dfp); 
			exit(3);  // error - can't write to file
		}
	}
	fclose(sfp); 
	fclose(dfp); 

	return 0;
}

