// Unit10_Random1.c
#include <stdio.h>
#include <stdlib.h>

int main(void) {
	int i;

	for (i = 1; i <= 10; i++)
		printf("%d\n", rand());

	return 0;
}

