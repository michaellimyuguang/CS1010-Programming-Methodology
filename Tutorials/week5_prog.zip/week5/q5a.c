// q5a.c
#include <stdio.h>

int main(void) {
	int i; 
	float f;
	double d;

	printf("i = %d; f = %f; d = %lf\n", i, f, d);
	return 0;
}

